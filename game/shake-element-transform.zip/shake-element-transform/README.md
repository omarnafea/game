
# shake-js

### [Demo](https://moulson.github.io/shake-js/demo.html)

### Usage
basic usage

    $('#element').shake();

You can also supply a parameter to control the length of the effect, in ms. The default is 100.

    $('#element').shake(300);
